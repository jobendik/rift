/**
 * @author Mugen87 / https://github.com/Mugen87
 */

import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import world from './core/World.js';

// Console color logging for better debugging
const logStyles = {
  info: 'color: #2196F3',
  success: 'color: #4CAF50',
  warning: 'color: #FF9800',
  error: 'color: #F44336; font-weight: bold'
};

function log(message, type = 'info') {
  console.log(`%c${message}`, logStyles[type] || '');
}

log('RIFT5: Starting Three.js Migration Fixes', 'info');
log(`Three.js version: ${THREE.REVISION}`, 'info');

// Create a custom loading manager to track progress
const loadingManager = new THREE.LoadingManager();
window.loadingManager = loadingManager; // Make it globally available for the AssetManager

// Set up loading screen UI interactions
const loadingScreen = document.getElementById('loadingScreen');
const startScreen = document.getElementById('startScreen');
const progressBar = document.getElementById('progressBar');
const loadingText = document.getElementById('loadingText');

loadingManager.onProgress = (url, itemsLoaded, itemsTotal) => {
  const progress = Math.floor((itemsLoaded / itemsTotal) * 100);
  if (progressBar) progressBar.style.width = `${progress}%`;
  if (loadingText) loadingText.textContent = `Loading assets... ${progress}%`;
  log(`Loading: ${url} (${itemsLoaded}/${itemsTotal})`, 'info');
};

loadingManager.onLoad = () => {
  log('All assets loaded successfully!', 'success');
  
  if (loadingScreen) {
    loadingScreen.classList.add('fade-out');
    setTimeout(() => {
      loadingScreen.classList.add('hidden');
      if (startScreen) startScreen.classList.remove('hidden');
    }, 1000);
  }
};

loadingManager.onError = (url) => {
  log(`Error loading: ${url}`, 'error');
  
  if (loadingText) {
    loadingText.innerHTML = "Error loading application. Check console for details.";
  }
  if (progressBar) {
    progressBar.style.backgroundColor = '#e74c3c';
  }
};

// Fix 1: Ensure SRGBColorSpace is defined
if (THREE.SRGBColorSpace === undefined) {
  log('Adding SRGBColorSpace definition', 'warning');
  // THREE.SRGBColorSpace = 'srgb'; // Commented out to prevent esbuild error
}

// Fix 2: Create a wrapper around TextureLoader to fix colorSpace
const originalTextureLoader = THREE.TextureLoader.prototype.load;
THREE.TextureLoader.prototype.load = function(url, onLoad, onProgress, onError) {
  return originalTextureLoader.call(this, url, 
    texture => {
      if (texture) {
        texture.colorSpace = THREE.SRGBColorSpace;
        log(`Texture colorspace fixed: ${url}`, 'success');
      }
      if (onLoad) onLoad(texture);
    },
    onProgress,
    error => {
      log(`Error loading texture: ${url}`, 'error');
      console.error(error);
      if (onError) onError(error);
    }
  );
};

// Fix 3: Create a wrapper around GLTFLoader to fix materials
const originalGltfLoaderLoad = GLTFLoader.prototype.load;
GLTFLoader.prototype.load = function(url, onLoad, onProgress, onError) {
  return originalGltfLoaderLoad.call(this, url, 
    gltf => {
      if (gltf && gltf.scene) {
        gltf.scene.traverse(object => {
          if (object.isMesh && object.material) {
            if (Array.isArray(object.material)) {
              object.material.forEach(material => {
                if (material.map) material.map.colorSpace = THREE.SRGBColorSpace;
                if (material.lightMap) material.lightMap.colorSpace = THREE.SRGBColorSpace;
                material.needsUpdate = true;
              });
            } else {
              if (object.material.map) object.material.map.colorSpace = THREE.SRGBColorSpace;
              if (object.material.lightMap) object.material.lightMap.colorSpace = THREE.SRGBColorSpace;
              object.material.needsUpdate = true;
            }
          }
        });
        log(`GLTF materials fixed: ${url}`, 'success');
      }
      if (onLoad) onLoad(gltf);
    },
    onProgress,
    error => {
      log(`Error loading GLTF: ${url}`, 'error');
      console.error(error);
      if (onError) onError(error);
    }
  );
};

// Wait for DOM to be ready
document.addEventListener('DOMContentLoaded', () => {
  log('DOM ready, setting up event handlers', 'info');
  
  // Initialize the pointer lock overlay
  const pointerLockOverlay = document.getElementById('pointerLockOverlay');
  if (pointerLockOverlay) {
    // Initially hide the overlay
    pointerLockOverlay.classList.add('hidden');
    
    // Preload the pause screen module
    import('../app/pauseScreen.js').then(module => {
      window.pauseScreen = module;
      log('Pause screen module preloaded', 'success');
    }).catch(error => {
      log(`Error preloading pause screen module: ${error.message}`, 'error');
    });
    
    // Add click handler to resume game
    pointerLockOverlay.addEventListener('click', () => {
      // Request pointer lock when overlay is clicked
      document.body.requestPointerLock();
      pointerLockOverlay.classList.add('hidden');
    });
    
    // Setup button handlers
    const resumeButton = document.getElementById('resumeButton');
    if (resumeButton) {
      resumeButton.addEventListener('click', () => {
        document.body.requestPointerLock();
        pointerLockOverlay.classList.add('hidden');
      });
    }
    
    const quitButton = document.getElementById('quitButton');
    if (quitButton) {
      quitButton.addEventListener('click', () => {
        window.location.reload();
      });
    }
  }
  
  const startButton = document.getElementById('start');
  if (startButton) {
    startButton.addEventListener('click', () => {
      log('Game starting...', 'info');
      
      // Completely hide and remove the start screen
      if (startScreen) {
        startScreen.classList.add('hidden');
        startScreen.style.display = 'none';
        // Actually remove from DOM to avoid any interference
        setTimeout(() => {
          if (startScreen.parentNode) {
            startScreen.parentNode.removeChild(startScreen);
          }
        }, 100);
      }
      
      try {
        // Initialize the world
        try {
          world.init();
        } catch (error) {
          log(`Error during world initialization: ${error.message}`, 'error');
          console.error(error);
        }
      } catch (error) {
        log(`Critical error starting game: ${error.message}`, 'error');
        console.error(error);
      }
    });
  } else {
    log('Warning: Start button not found in the DOM!', 'warning');
  }
});

// Export the world for debugging
window.gameWorld = world;
